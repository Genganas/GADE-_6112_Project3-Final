﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE_6112_Project2
{
    internal class Obstacle : Tile
    {
        public Obstacle(int x, int y) : base(x, y)
        {

        }
    }
}
